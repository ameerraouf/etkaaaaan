<?php

namespace Intervention\Image\Exception;

class NotWritableException extends ImageException
{
    # nothing to override
}
