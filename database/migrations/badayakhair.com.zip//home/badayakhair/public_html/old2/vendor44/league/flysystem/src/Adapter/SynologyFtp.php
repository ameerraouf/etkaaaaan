<?php

namespace League\Flysystem\Adapter;

class SynologyFtp extends Ftpd
{
    // This class merely exists because of BC.
}
