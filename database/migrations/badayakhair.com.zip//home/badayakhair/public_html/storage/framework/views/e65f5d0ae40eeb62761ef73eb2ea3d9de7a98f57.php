<?php $__env->startSection('theme'); ?>


<div class="mainslider">
				<div id="homeslider" class="owl-carousel">
				<?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
			  	<div class="item">
			  	    <a href="<?php echo e($slide->url); ?>">
			  		<img src="<?php echo e(url('upload/'.$slide->photo)); ?>" style="width:100%;height:500px;" alt="">
			  		<span><?php echo e($slide->title); ?></span>
			  	    </a>
			  	</div><!-- end item -->
  				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div><!-- End homeslider -->
				<div class="clearfix"></div>
			</div><!-- end mainslider -->
			
			<div class="bannersarea1">
				<div class="row">

					 	<?php echo Set::banner('top','one','6'); ?>

				 
				</div><!-- end row -->
			</div><!-- end bannersarea1 -->

			<div class="lastnews">
				<div class="title"><span>جديد الأخبار</span></div>
				<div class="row">
				  <?php $__currentLoopData = $allnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
					<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
						<div class="postitem">
							<a href="<?php echo e(url('news/'.$news->id.'/'.$news->title)); ?>" title="<?php echo e($news->title); ?>">
							 <?php if(!empty($news)): ?>
								<img src="<?php echo e(url('upload/'.$news->photo)); ?>" alt="">
							 <?php endif; ?>	
								<div class="content">
									<h1><?php echo e($news->title); ?></h1>
									<h2><?php echo e(mb_substr(strip_tags($news->content),0,200, "utf-8")); ?></h2>
									<span><i class="fa fa-arrow-circle-left" aria-hidden="true"></i> إقرأ التفاصيل</span>
								</div><!-- end content -->
							</a>
						</div><!-- end postitem -->
					</div><!-- end col-lg-6 -->
				  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					<div class="clearfix"></div>
				</div><!-- end row -->
				<div class="morenews"><a href="<?php echo e(url('all/news')); ?>" title="المزيد من الأخبار">المزيد من الأخبار</a></div>
			</div><!-- end lastnews -->

			<div class="lastmedia">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
						<div class="lastimages">
							<div class="title">معرض الصور</div>
							<div class="galleryitem">
							<?php 
							 $pic_dep = App\Department::where('parent',9)->get(['id']);
							?>
							<?php $__currentLoopData = App\News::whereIn('department',$pic_dep)->orWhere('department',9)->orderBy('id','desc')->take(1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo e(url('news/'.$pics->id.'/'.$pics->title)); ?>" title="<?php echo e($pics->title); ?>">
											<img src="<?php echo e(url('upload/'.$pics->photo)); ?>" alt="">
									<span><i class="fa fa-search-plus" aria-hidden="true"></i></span>
								</a>
							 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</div><!-- end galleryitem -->
							<div class="moremedia"><a href="<?php echo e(url('category/9')); ?>" title="المزيد">المزيد <i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a></div>
						</div><!-- end lastimages -->
					</div><!-- end col-lg-6 -->
					<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
						<div class="lastvideo">
							<div class="title">جديد الفيديو</div>
							<div class="row">
							<?php $video_dep = App\Department::where('parent',8)->get(['id']); ?>
							 <?php $__currentLoopData = App\News::whereIn('department',$video_dep)->orWhere('department',8)->orderBy('id','desc')->take(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
									<div class="videoitem">
										<a href="<?php echo e(url('news/'.$videos->id.'/'.$videos->title)); ?>" title="<?php echo e($videos->title); ?>">
										  
										  <?php $youtube = explode('||',$videos->youtube); ?>
										  <?php if(!empty($videos->photo)): ?>
											<img src="<?php echo e(url('upload/'.$videos->photo)); ?>" alt="">
										  <?php else: ?>

										  <?php if(!empty($youtube[0])): ?>
										  <img src="https://i1.ytimg.com/vi/<?php echo e(Set::youtubelink($youtube[0])); ?>/hqdefault.jpg" alt="">
										  <?php elseif(!empty($youtube[1])): ?>
										  <img src="https://i1.ytimg.com/vi/<?php echo e(Set::youtubelink($youtube[1])); ?>/hqdefault.jpg" alt="">
										  <?php endif; ?>

										  <?php endif; ?>	
											<span><i class="fa fa-play" aria-hidden="true"></i></span>
										</a>
									</div><!-- end videoitem -->
								</div><!-- end col-lg-6 -->
							 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div><!-- end row -->
							<div class="moremedia"><a href="<?php echo e(url('category/8')); ?>" title="المزيد">المزيد <i class="fa fa-arrow-circle-left" aria-hidden="true"></i></a></div>
						</div><!-- end lastvideo -->
					</div><!-- end col-lg-6 -->
				</div><!-- end row -->
			</div><!-- end lastmedia -->

			<div class="twitta">
				<div class="title"><span>أحدث التغريدات</span></div>
				<div class="content">
					<a class="twitter-timeline"
          href="https://twitter.com/badayakhair"
          data-chrome="noheader nofooter noborders nofooter noscrollbar transparent"
          data-link-color="#000000"
          data-theme="light"
          data-aria-polite="assertive"
          data-tweet-limit="1"> Tweets by @TwitterDev  </a>
        	<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
				</div>
			</div><!-- end twitta -->
			
			<div class="bannersarea2">
				<div class="row">
					 <?php echo Set::banner('bottom','one','6'); ?>

				</div><!-- end row -->
			</div><!-- end bannersarea2 -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make(app('tmp').'.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>