	</div><!-- end container -->
	</div><!-- End Wrapper -->

	<div id="footer2">
    <div class="container">
      <div class="copyright">
		 		جميع الحقوق محفوظة لـ <a href="<?php echo e(url('/')); ?>" title="<?php echo e(Set::set()->sitename); ?>"><?php echo e(Set::set()->sitename); ?></a> © <?php echo e(date('Y')); ?>

			</div><!-- end copyright -->
			<div class="const">
				<a target="_blank" title="مؤسسة كوكبة التقنية" href="http://const-tech.com.sa"><img alt="مؤسسة كوكبة التقنية" src="<?php echo e(url('style')); ?>/images/const.png"></a>
		 	</div><!-- end const -->
      <div class="clearfix"></div>
    </div><!-- end container -->
    </div><!-- End Footer2 -->

 	<!--[if lt IE 8 ]>
 	<script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.2/CFInstall.min.js"></script>
 	<script>window.attachEvent("onload",function(){CFInstall.check({mode:"overlay"})})</script>
 	<![endif]-->
 
 	<!-- Javascript -->
 	<script type="text/javascript" src="<?php echo e(url('style')); ?>/js/modernizr.custom.97442.js"></script>
 	<script type="text/javascript" src="<?php echo e(url('style')); ?>/js/bootstrap-rtl.min.js"></script>
 	<script type="text/javascript" src="<?php echo e(url('style')); ?>/js/owl.carousel.min.js"></script>
 	<script type="text/javascript" src="<?php echo e(url('style')); ?>/js/more.js"></script>
	<!-- Javascript -->
</body>
</html>