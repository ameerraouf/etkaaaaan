<?php $__env->startSection('theme'); ?>
<?php if($page->active == 1): ?>
 	<div class="pagefile">
        <div class="title"><?php echo e($title); ?></div>
        <div class="content">
          <?php echo $page->content; ?>

        </div><!-- end content -->
      </div><!-- end pagefile -->
<?php else: ?>
 <div class="alert alert-danger">
 	<h1>هذه الصفحة غير متاحة حاليا</h1>
 </div>
<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make(app('tmp').'.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>